# 镜头分类与命名

本站目前有 19 个可运行预设和 257 条外部参考索引，两者分别计数。

## 可运行预设

| 分类 | 中文名称 | 稳定代码 ID |
|---|---|---|
| 镜头运动 | 右下角缓慢放大 | `zoom-bottom-right` |
| 镜头运动 | 缩小展开 | `zoom-out` |
| 镜头运动 | 缓慢向上 | `drift-up` |
| 文字入场 | 左弹打字 | `left-bounce` |
| 文字入场 | 向右弹打字 | `right-bounce` |
| 文字入场 | 模糊向上打字 | `blur-up` |
| 卡片动效 | 轻摆卡片 · 完整场景 | `vibe-card` |
| 卡片动效 | 卡片正弦轻摆 | `card-sway` |
| 标签动效 | 标签往返漂移 | `chip-drift` |
| 进度动效 | 进度条线性填充 | `progress-fill` |

Vibe Motion 只有一个原始示例。新增的完整场景和三个独立动作来自对该示例的拆分，不是四个不同的原始素材。

## XCYJ 参考索引

[可搜索目录](../references.html) · [CSV 清单](../downloads/xcy-shot-index.csv)

保留作者镜头名称，使用 XCY-类别缩写-三位序号编号；原站 ID 和地址作为稳定标识。原站公开页面未提供组件源码或转载许可，本站仅整理名称、类别、风格与入口，不镜像视频、不将这些条目标记为可下载组件。

- 人物口播（SP）：2 个
- 信息卡片（CD）：17 个
- 数据可视化（DT）：36 个
- 界面演示（UI）：11 个
- 对话与终端（AI）：8 个
- 叙事场景（SC）：29 个
- 引用与评论（QT）：5 个
- 背景与转场（BG）：20 个
- 结尾引导（EN）：7 个
- 空间文字（TY）：60 个
- 遮罩转场（MK）：13 个
- 路径与纵深（DP）：20 个
- 形变与粒子（FX）：29 个

## 新增参考视频组

- **惊叹文字横向拉长**（`reaction-stretch`）：逐字延长 → 横向铺满。
- **人物缩至左下角**（`presenter-corner`）：全屏人物 → 左下小窗。
- **多图模糊弹出**（`blur-collage`）：错峰放大 → 去模糊 → 拼贴。
- **开场标题下落**（`headline-drop`）：双图弹入 → 标题下落 → 擦除。
- **卡片依次展示聚合**（`cards-assemble`）：逐卡放大展示 → 缩入五卡布局。
- **图表弹出叠加标题**（`evidence-pop`）：双图错峰 → 结论标题出现。
- **双侧图片翻转替换**（`double-flip`）：左右弹入 → 翻面 → 第二组。
- **大字冲屏切换封面**（`cover-punch`）：大字入场 → 放大模糊 → 新封面。
- **背景上移模糊轮播**（`background-rise`）：背景依次上移 → 聚焦 → 淡出。

[使用与素材说明](story-api.md)

## 2026-10-13 · 十个新镜头

| 分类 | 名称 | ID | 原文件 |
|---|---|---|---|
| type | 文字内缩外放换词 | `text-contract-expand` | 内缩外放-1.mp4 |
| collage | 三卡错峰向上弹出 | `triple-rise` | 向上弹出三个-1.mp4 |
| transition | 文字向右吸入文件夹 | `folder-collect` | 向右被文件夹吸走-1.mp4 |
| badge | 图标上弹与双标签展开 | `icon-rise-badges` | 图标向上弹-1.mp4 |
| layout | 圆形头像缩至左下 | `avatar-circle-corner` | 头像缩小左下-1.mp4 |
| collage | 左右卡片翻开弹入 | `side-card-reveal` | 左右弹出-1.mp4 |
| type | 大字分开与下方换标题 | `headline-split-swap` | 文字动效-1.mp4 |
| type | 关键词错峰下落汇总 | `keywords-drop` | 文字掉下来-1.mp4 |
| card | 图标切换与画面弹出 | `panel-pop` | 画面弹-1.mp4 |
| transition | 鼠标拉下页面并收拢 | `cursor-page-pull` | 鼠标下拉页面-1.mp4 |

[预览这组镜头](../examples/october-13.html) · [动作与参数](october-13.md)
